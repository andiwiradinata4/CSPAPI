﻿namespace LearnAPINetCore.Library.Models
{
    public class DefaultServer
    {
        public static string Server = "";
        public static string Database = "";
        public static string SAID = "";
        public static string SAPassword = "";
        public static string ApplicationName = "";

        public DefaultServer(string server, string database, string said, string sapassword, string applicationname)
        {
            Server = server;
            Database = database;
            SAID = said;
            SAPassword = sapassword;
            ApplicationName = applicationname;
        }

    }
}

﻿using LearnAPINetCore.Library.Models;

namespace LearnAPINetCore.Library.SharedLib
{
    public class SetupConfiguration
    {
        public IConfiguration _configuration;
        public SetupConfiguration(IConfiguration configuration)
        {
            _configuration = configuration;

        }

        public IConfiguration GetConfiguration() { return _configuration; }
        public DefaultServer GetDefaultServer()
        {
            return new DefaultServer(
                server: _configuration[key: "Connection:Server"],
                database: _configuration[key: "Connection:Database"],
                said: _configuration[key: "Connection:SAID"],
                sapassword: _configuration[key: "Connection:SAPassword"],
                applicationname: _configuration[key: "Connection:ApplicationName"]);
        }
    }
}

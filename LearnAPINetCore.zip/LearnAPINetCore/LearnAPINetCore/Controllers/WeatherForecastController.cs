using Microsoft.AspNetCore.Mvc;

namespace LearnAPINetCore.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
        "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
    };

        private readonly ILogger<WeatherForecastController> _logger;
        public IConfiguration _configuration;


        //public WeatherForecastController(ILogger<WeatherForecastController> logger)
        //{
        //    _logger = logger;
        //}

        public WeatherForecastController(IConfiguration configuration)
        {
            _configuration = configuration;
        }


        [HttpGet("GetWeatherForecast")]
        public IEnumerable<WeatherForecast> Get()
        {
            return Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = DateTime.Now.AddDays(index),
                TemperatureC = Random.Shared.Next(-20, 55),
                Summary = Summaries[Random.Shared.Next(Summaries.Length)]
            })
            .ToArray();
        }

        [HttpGet("GetString")]
        public string GetString(string name)
        {
            return name + " | " + Library.Models.DefaultServer.Server;

            //string Server = _configuration[key: "Connection:Server"];
            //string Databse = _configuration[key: "Connection:Database"];
            //string SAID = _configuration[key: "Connection:SAID"];
            //string SAPassword = _configuration[key: "Connection:SAPassword"];
            //string ApplicationName = _configuration[key: "Connection:ApplicationName"];
            //return name + " - " + Server + " - " + Databse + " - " + SAID + " - " + SAPassword + " - " + ApplicationName;
        }

        [HttpPost("PostString")]
        public string PostString(string name)
        {
            Library.Models.DefaultServer.Server = "123";
            return name + " | " + Library.Models.DefaultServer.Server;
        }



    }
}